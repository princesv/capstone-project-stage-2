package com.prince.teamaveonracing;

public class Temperature {
    Double temperature;

    public Temperature(Double temperature) {
        this.temperature = temperature;
    }

    public Double getTemperature() {
        return temperature;
    }

    public void setTemperature(Double temperature) {
        this.temperature = temperature;
    }
}
