package com.prince.teamaveonracing;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
    Temperature temp = new Temperature(25.6);
    Location location = new Location(37.427777,-122.07522222);
    FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    DatabaseReference temperatureReference = firebaseDatabase.getReference("Temperature Value");
    DatabaseReference locationReference = firebaseDatabase.getReference("Location");
    DatabaseReference membersReference = firebaseDatabase.getReference("Team Members");
    TextView name;
    TextView contact;
    TextView image;
    TextView year;
    TextView subteam;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name = findViewById(R.id.name);
        contact = findViewById(R.id.contact);
        year = findViewById(R.id.year);
        image = findViewById(R.id.img);
        subteam = findViewById(R.id.subteam);
        temperatureReference.setValue(temp);
        locationReference.setValue(location);
    }
    public void addArtist(View view){
        String nameS=name.getText().toString().trim();
        String contactS = contact.getText().toString().trim();
        contactS = "http://wa.me/91"+contactS;
        String imageS = image.getText().toString().trim();
        String yearS=year.getText().toString().trim();
        String subteamS = subteam.getText().toString().trim();

            String id=membersReference.push().getKey();
            TeamMember teamMember = new TeamMember(id,nameS,yearS,contactS,imageS,subteamS);
            membersReference.child(id).setValue(teamMember);
        Toast.makeText(this, "push successful", Toast.LENGTH_SHORT).show();

    }

}
